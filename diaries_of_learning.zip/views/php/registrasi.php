<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registrasi</title>
    <link rel="stylesheet" href="./views/css/login.css">
</head>
<body>
    <div class="login-box">
        <h2>Silahkan Registrasi</h2>
        <form action="index.php?page=login_process" method="POST">
            <div class="input-group">
                <label>Username:</label>
                <input type="text" name="username" required>
            </div>
            <div class="input-group">
                <label>Password:</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit">Registrasi</button>
        </form>
    </div>
</body>
</html>
