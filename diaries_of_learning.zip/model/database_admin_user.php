<?php
function user_get_all($koneksi) {
    $sql = "SELECT * FROM user";
    $result = mysqli_query($koneksi, $sql);
    if (!$result) return [];
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>